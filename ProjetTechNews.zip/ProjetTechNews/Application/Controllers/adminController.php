<?php
/*
====================================================
newsController.php
====================================================
*/
namespace Application\Controllers ;

class adminController extends \Application\Controllers\appController {

    public function connexion (){

    $this->render('admin\connexion', 'connexion') ;

    } // FIN public function connexion


} // FIN class adminController extends \Application\Controllers\appController
