


<h1 style text-align="center" />  Connexion Administrateur</h1>
<form style text-align="center" >
				<input type="text" placeholder="Administrateur" disabled /><br/><br/>
				<input type="email" Email /><br/><br/><br/>
				<input type="submit" value="Connexion"/><br/><br/>
</form>
